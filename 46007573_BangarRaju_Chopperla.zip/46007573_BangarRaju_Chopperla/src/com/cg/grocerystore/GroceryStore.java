package com.cg.grocerystore;

import java.util.Scanner;

public class GroceryStore {

	private double discount;

	public double Calculation(double amount, int choice) {

		double finalAmount = 0;

		switch (choice) {

		case 1:
			discount = (amount * 30) / 100;
			finalAmount = amount - discount;
			break;
		case 2:
			discount = (amount * 10) / 100;
			finalAmount = amount - discount;
			break;
		case 3:
			discount = (amount * 5) / 100;
			finalAmount = amount - discount;
			break;

		case 4:
			int amt = (int) (amount / 100);
			discount = amt * 5;
			finalAmount = amount - discount;
			break;

		case 5:
			finalAmount = amount;
			break;

		default:
			System.out.println("Invalid choice. Please select valid options");
			System.exit(0);

		}

		return finalAmount;
	}

	public static void main(String[] args) {
		GroceryStore retailstore = new GroceryStore();
		Scanner scanner = new Scanner(System.in);
		System.out.println(
				"Select type of User\n 1.Employee of the store\n 2.Affiliate of the store\n 3.Customer for over 2 years \n 4.User is none of the above 3 options \n 5.No discount on Groceries ");
		int choice = scanner.nextInt();
		System.out.println("Enter User Name");
		String customerName = scanner.next();
		System.out.println("Enter the bill amount");
		double billAmount = scanner.nextDouble();

		System.out.println("Total bill :" + retailstore.Calculation(billAmount, choice));

	}

}
