package com.cg.grocerystore;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class GroceryStoreTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {

	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@Test
	void testCalculation() {
		GroceryStore retailstore = new GroceryStore();
		assertEquals(700, retailstore.Calculation(1000, 1));
	}

	@Test
	void testCalculation1() {
		GroceryStore retailstore = new GroceryStore();
		assertEquals(900, retailstore.Calculation(1000, 2));
	}

	@Test
	void testCalculation2() {
		GroceryStore retailstore = new GroceryStore();
		assertEquals(950, retailstore.Calculation(1000, 3));
	}

	@Test
	void testCalculation3() {
		GroceryStore retailstore = new GroceryStore();
		assertEquals(700, retailstore.Calculation(1000, 1));
	}

}
